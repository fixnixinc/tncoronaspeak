anna  = [4,3,6]
banna = [2,3,5]
banna = [x+y for x,y in zip(banna,anna)]
print(banna)
